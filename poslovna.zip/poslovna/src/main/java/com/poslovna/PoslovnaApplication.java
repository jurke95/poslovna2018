package com.poslovna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoslovnaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoslovnaApplication.class, args);
	}
}
